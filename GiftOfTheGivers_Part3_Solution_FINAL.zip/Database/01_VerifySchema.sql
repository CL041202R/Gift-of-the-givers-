-- Part 3, C.3 evidence helper: run in the Azure Portal > SQL database > Query editor
-- (before AND after the pipeline run) and screenshot the results.

SELECT t.name AS TableName, SUM(p.rows) AS [RowCount]
FROM sys.tables t
JOIN sys.partitions p ON p.object_id = t.object_id AND p.index_id IN (0, 1)
GROUP BY t.name
ORDER BY t.name;

SELECT name AS ObjectName, type_desc, create_date
FROM sys.objects
WHERE name IN ('vw_ProjectDonationTotals', 'IX_Donations_UserId');
