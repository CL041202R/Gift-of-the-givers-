-- Part 3, C.3: lightweight, IDEMPOTENT schema update applied by the pipeline
-- (stage Deploy > job DeploySqlSchema). Safe to run on every deployment:
-- every change is guarded, so re-running does nothing the second time.
-- Kept deliberately small to stay within the B1 / Basic-tier limits.
--
-- Prerequisite: the tables already exist. The web app creates them on first
-- start via DbInitializer (EnsureCreatedAsync); the pipeline warms the site
-- up before running this script.

-- 1. Index to speed up "my donations" lookups for logged-in donors.
IF EXISTS (SELECT 1 FROM sys.tables WHERE name = 'Donations')
   AND NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Donations_UserId')
BEGIN
    CREATE INDEX IX_Donations_UserId ON dbo.Donations (UserId);
    PRINT 'Created index IX_Donations_UserId';
END
ELSE PRINT 'Index IX_Donations_UserId already present (or table missing) - skipped';
GO

-- 2. Reporting view: total raised per relief project and currency.
--    CREATE OR ALTER makes re-running safe.
IF EXISTS (SELECT 1 FROM sys.tables WHERE name = 'Donations')
   AND EXISTS (SELECT 1 FROM sys.tables WHERE name = 'ReliefProjects')
EXEC('
CREATE OR ALTER VIEW dbo.vw_ProjectDonationTotals AS
SELECT p.ProjectId,
       p.ProjectName,
       d.Currency,
       COUNT(d.DonationId)  AS DonationCount,
       SUM(d.Amount)        AS TotalRaised
FROM dbo.ReliefProjects p
LEFT JOIN dbo.Donations d ON d.ProjectId = p.ProjectId
GROUP BY p.ProjectId, p.ProjectName, d.Currency;
');
PRINT 'Schema update complete';
GO
