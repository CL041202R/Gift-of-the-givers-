# Part 3 — Testing, Deployment, and Handover

This solution extends the Part 2 codebase with:

- **`GiftOfTheGivers.Tests`** — now also contains **integration tests**
  (`DonationIntegrationTests.cs`) and extra **unit/validation tests**
  (Section A.1, A.2), alongside the Part 2 helper tests.
- **`DonationFunctionIntegrationTests.cs`** — new: form → Azure Function → database chain test (A.2).
- **`GiftOfTheGivers.UiTests`** — new xUnit + Selenium project with two UI
  scenarios: employee login, and anonymous donor donation (Section A.4).
- **`LoadTest/`** — a k6 script (and a no-install .NET fallback) simulating
  5 concurrent users (Section A.3).
- **`azure-pipelines.yml`** — rewritten as a three-stage pipeline:
  `Build_And_Test` (unit + integration, every push), `UITests` (Selenium,
  every push), `Deploy` (App Service + Function App + Azure SQL schema
  update, `main` branch only) (Sections B & C).
- **`HandoverPackage/`** — the Section D deliverables: `UserManual.docx`
  and `TeamContributionReport.docx`, plus the small Node scripts that
  generated them (kept so you can regenerate after filling in your
  team's real names/screenshots).

As with Part 2, everything that can be built as code is built and ready to
run. Steps that must happen inside **your team's own Azure DevOps
organisation / Azure subscription / Visual Studio** are marked **ACTION
(your team)** — take the listed screenshots for your submission at each
one.

---

## Section A: Testing the Application

### A.1 Unit Tests (already built)

`GiftOfTheGivers.Tests/DonationHelpersTests.cs` and the new
`DonationValidationTests` class cover, per the brief's examples:

- **Certificate formatting** — `FormatCertificateNumber_ReturnsExpectedFormat`, `FormatCertificateNumber_ThrowsForInvalidId`
- **Total calculation** — `CalculateDonationTotal_SumsAndRoundsCorrectly`, `CalculateDonationTotal_EmptyCollection_ReturnsZero`
- **Donation validation** — `Donation_WithZeroAmount_FailsValidation`, `Donation_WithValidAmount_PassesValidation`
- Currency formatting edge cases

**ACTION (your team):** run `dotnet test GiftOfTheGivers.Tests` (or Test
Explorer in Visual Studio) and screenshot the passing results.

### A.2 Integration Tests (already built)

`DonationIntegrationTests.cs` hosts the real `GiftOfTheGivers.Web` app
in-process (via `WebApplicationFactory<Program>`) and drives the donation
flow exactly as a browser would: `GET /Donation` → `POST /Donation/Create`
as a guest → follows the redirect to `/Donation/Certificate/{id}` → asserts
the certificate renders with a correctly formatted number **and** checks
the donation/certificate rows directly in the database. This is the
"donation flow from form > function > database" scenario the brief asks
for — using the shared `GiftOfTheGivers.Helpers` logic that both the web
app and the `GenerateTaxCertificate` Function call.

**ACTION (your team):** run the tests and screenshot the result.

### A.3 Load and Stress Testing (already built)

See `LoadTest/README.md`. Two options are provided (k6, or a
`dotnet script` fallback needing no extra install) that simulate 5
concurrent users browsing Home/Donate/Volunteer for 30 seconds.

**ACTION (your team):** run it against your locally running app or,
better, your deployed App Service (once Section C.1 is done), and
screenshot the results table.

### A.4 Selenium UI Tests (already built)

`GiftOfTheGivers.UiTests` contains:

- `EmployeeLoginTests` — logs in with the seeded demo Employee account,
  clicks through to the Dashboard, and confirms role-gated content appears.
- `AnonymousDonationTests` — fills in the Donate form as a guest and
  confirms the generated certificate page appears with the correct name
  and certificate-number format.

Both read the site's base URL from the `GOTG_BASE_URL` environment
variable (defaults to `http://localhost:5000`), so the same tests work
locally and in CI.

**ACTION (your team):**
1. Run `dotnet run --urls http://localhost:5000` from `GiftOfTheGivers.Web`
   in one terminal.
2. In another terminal: `dotnet test GiftOfTheGivers.UiTests`.
3. Screenshot the passing test results (and optionally a screen recording
   of the headless run, or set `--headless=new` off in
   `SeleniumTestBase.cs` temporarily to watch it drive a real browser
   window).

---

## Section B: Integrating Tests into Azure Pipelines

`azure-pipelines.yml`'s **`Build_And_Test`** stage now runs
`GiftOfTheGivers.Tests` (unit *and* integration tests together) on every
push automatically, publishing `.trx` results (B.1). The separate
**`UITests`** stage starts the web app on the agent and runs the Selenium
suite against it — also on every push (B.1/B.2) — without blocking the
`Deploy` stage if a UI test is flaky on a given agent
(`continueOnError: true`).

**ACTION (your team):**
1. In Azure DevOps, your existing pipeline (from Part 2) will pick up the
   new YAML automatically on your next push — or re-run **Pipelines >
   [your pipeline] > Edit** to confirm it's reading the updated file.
2. Push a small code change to trigger a run. Screenshot: the three-stage
   pipeline view, the `Build_And_Test` stage's test results tab (green,
   showing unit + integration test counts), and the `UITests` stage's test
   results tab.

---

## Section C: Continuous Deployment

The `Deploy` stage in `azure-pipelines.yml` has three parallel jobs, only
triggered on pushes to `main`:

- **`DeployWebApp`** — publishes `GiftOfTheGivers.Web` and deploys it to
  an Azure App Service (Linux) via the `AzureWebApp@1` task (C.1).
- **`DeployFunctions`** — publishes `GiftOfTheGivers.Functions` and
  deploys it to an Azure Function App (Linux) via `AzureFunctionApp@2`
  (C.2).
- **`DeploySqlSchema`** — warms the deployed site up (the app creates its
  tables on first start), then runs `Database/02_LightweightSchemaUpdate.sql`
  (idempotent: an index + a reporting view) against Azure SQL via
  `SqlAzureDacpacDeployment@1` (C.3).

**ACTION (your team):** follow `SUBMISSION_RUNBOOK.md` — run
`deploy/azure-setup.sh` in Azure Cloud Shell (creates everything and prints
the pipeline variable values), create the service connection, add the
variables, push to `main`. **No EF migration is needed.**

**Reflect** briefly in your submission on why cloud deployment matters
   here — e.g. an App Service can scale out automatically if donation
   traffic spikes right after a disaster is reported, which a single
   on-premises server can't do as quickly.

---

## Section D: Project Handover & User Manual

`HandoverPackage/UserManual.docx` is written for non-technical Foundation
staff and covers, per the brief: logging in as Employee/Donor/Anonymous,
posting an update, making a donation (guest, once-off, recurring,
currencies), downloading a tax certificate, and registering as a
volunteer. It includes **placeholder screenshot boxes** —
`[Insert screenshot: ...]` — at each relevant step.

`HandoverPackage/TeamContributionReport.docx` is a one-page template with
a table of role/responsibility/evidence, pre-filled with the four
suggested roles from the brief (Project Lead, Database Designer,
Developer, Quality Reviewer) plus a fifth Deployment Lead row, since this
project also needed CI/CD and Selenium work.

**ACTION (your team) — before submitting:**
1. Run the app locally (or open your deployed site) and take the actual
   screenshots the manual calls for; paste each one over its
   `[Insert screenshot: ...]` placeholder box in Word.
2. Edit `TeamContributionReport.docx`: replace every `[Team member name]`
   and `[Evidence]` placeholder with your group's real names and links
   (e.g. a commit URL or an Azure Boards work item link) to Azure Repos
   commits, Boards items, or pipeline runs each person is responsible for.
3. If you'd rather regenerate either document after editing its content
   (e.g. to change wording, not just add screenshots), edit the
   corresponding `build_*.js` script in `HandoverPackage/` and re-run
   `node build_user_manual.js` / `node build_team_contribution_report.js`
   (requires Node.js and `npm install docx` — or paste the generated text
   straight into Word instead).

---

## Submission checklist (from the brief)

- [ ] Screenshots of passing unit tests (A.1)
- [ ] Code + screenshots of the integration test run (A.2)
- [ ] Load test configuration + results screenshots (A.3)
- [ ] Selenium test code + execution results (A.4)
- [ ] Pipeline YAML/config + test logs showing tests running on each commit (B)
- [ ] Pipeline config + live-site evidence for App Service, Functions, and SQL deployment (C)
- [ ] Completed `UserManual.docx` with real screenshots (D)
- [ ] Completed `TeamContributionReport.docx` with real names/roles/evidence (D)
