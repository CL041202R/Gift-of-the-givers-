using Xunit;

// Integration tests each host the real web app (shared in-memory database
// + startup seeding), so run test classes one at a time to avoid races.
[assembly: CollectionBehavior(DisableTestParallelization = true)]
