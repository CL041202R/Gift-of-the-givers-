using System.Net;
using System.Text;
using System.Text.Json;
using GiftOfTheGivers.Functions;
using GiftOfTheGivers.Web.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging.Abstractions;
using Xunit;

namespace GiftOfTheGivers.Tests;

/// <summary>
/// Part 3, Section A.2 (second integration test): the full
/// "form -> function -> database" chain.
///
/// 1. A donor submits the Donate form (web app, in-process).
/// 2. The donation + certificate are written to the database.
/// 3. The GenerateTaxCertificate Azure Function is invoked with that
///    donation's details (as a payment webhook / back-office call would).
/// 4. We assert the Function's certificate number is IDENTICAL to the one
///    stored in the database - proving both components share one
///    GiftOfTheGivers.Helpers implementation.
/// </summary>
public class DonationFunctionIntegrationTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly WebApplicationFactory<Program> _factory;

    public DonationFunctionIntegrationTests(WebApplicationFactory<Program> factory)
    {
        _factory = factory;
    }

    [Fact]
    public async Task FormToFunctionToDatabase_CertificateNumbersMatch()
    {
        // ---- Step 1: form -> web app -> database -------------------------
        var client = _factory.CreateClient(new WebApplicationFactoryClientOptions { AllowAutoRedirect = false });

        var page = await client.GetAsync("/Donation");
        var html = await page.Content.ReadAsStringAsync();
        var token = ExtractToken(html);
        var cookies = page.Headers.TryGetValues("Set-Cookie", out var sc)
            ? string.Join("; ", sc.Select(c => c.Split(';')[0]))
            : string.Empty;

        using var post = new HttpRequestMessage(HttpMethod.Post, "/Donation/Create");
        post.Headers.Add("Cookie", cookies);
        post.Content = new FormUrlEncodedContent(new Dictionary<string, string>
        {
            ["__RequestVerificationToken"] = token,
            ["ProjectId"] = "1",
            ["Amount"] = "1250",
            ["Currency"] = "ZAR",
            ["IsRecurring"] = "false",
            ["donateAsGuest"] = "true",
            ["guestName"] = "Function Chain Donor",
        });
        var created = await client.SendAsync(post);
        Assert.Equal(HttpStatusCode.Redirect, created.StatusCode);

        // ---- Step 2: read what the web app stored ------------------------
        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
        var donation = await db.Donations
            .Include(d => d.Certificate)
            .OrderByDescending(d => d.DonationId)
            .FirstAsync(d => d.DonorDisplayName == "Function Chain Donor");
        Assert.NotNull(donation.Certificate);

        // ---- Step 3: call the Azure Function with the same donation ------
        var function = new GenerateTaxCertificateFunction(NullLoggerFactory.Instance);
        var json = JsonSerializer.Serialize(new
        {
            donationId = donation.DonationId,
            amount = donation.Amount,
            currency = donation.Currency,
            donorName = donation.DonorDisplayName,
        });

        var httpContext = new DefaultHttpContext();
        httpContext.Request.Body = new MemoryStream(Encoding.UTF8.GetBytes(json));
        httpContext.Request.ContentType = "application/json";

        var result = await function.Run(httpContext.Request);

        // ---- Step 4: function output must agree with the database --------
        var ok = Assert.IsType<OkObjectResult>(result);
        var response = Assert.IsType<GenerateTaxCertificateFunction.CertificateResponse>(ok.Value);

        Assert.Equal(donation.Certificate!.CertificateNumber, response.CertificateNumber);
        Assert.Equal("ZAR 1,250.00", response.FormattedAmount);
    }

    [Fact]
    public async Task Function_RejectsInvalidDonation_WithBadRequest()
    {
        var function = new GenerateTaxCertificateFunction(NullLoggerFactory.Instance);
        var httpContext = new DefaultHttpContext();
        httpContext.Request.Body = new MemoryStream(Encoding.UTF8.GetBytes("{\"donationId\":0,\"amount\":-5,\"currency\":\"\"}"));

        var result = await function.Run(httpContext.Request);

        Assert.IsType<BadRequestObjectResult>(result);
    }

    private static string ExtractToken(string html)
    {
        var idx = html.IndexOf("__RequestVerificationToken", StringComparison.Ordinal);
        Assert.True(idx >= 0, "Anti-forgery token not found on Donate page.");
        var v = html.IndexOf("value=\"", idx, StringComparison.Ordinal) + "value=\"".Length;
        return html[v..html.IndexOf('"', v)];
    }
}
