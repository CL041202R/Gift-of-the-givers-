using System.Net;
using System.Net.Http.Json;
using GiftOfTheGivers.Web.Data;
using GiftOfTheGivers.Web.Models;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace GiftOfTheGivers.Tests;

/// <summary>
/// Part 3, Section A.2: integration test for the donation flow described in
/// the brief — "donation flow from form &gt; function &gt; database".
///
/// The web app's <c>DonationController.Create</c> action and the
/// <c>GenerateTaxCertificate</c> Azure Function both call the exact same
/// <c>GiftOfTheGivers.Helpers.DonationHelpers</c> logic (that's the point of
/// Part 2, Section D — one shared, independently tested package). This test
/// therefore exercises the equivalent end-to-end path — HTTP POST of a
/// donation form, through MVC model binding and the controller, into the
/// EF Core InMemory database, out to the certificate page — by hosting the
/// real <c>GiftOfTheGivers.Web</c> app in-process via
/// <see cref="WebApplicationFactory{TEntryPoint}"/>. This is the same code
/// path a request forwarded to the Function would ultimately rely on for
/// certificate-number formatting.
/// </summary>
public class DonationIntegrationTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly WebApplicationFactory<Program> _factory;

    public DonationIntegrationTests(WebApplicationFactory<Program> factory)
    {
        // Each test run gets its own isolated in-memory database instance so
        // tests never interfere with one another or with a developer's
        // locally running copy of the app.
        _factory = factory.WithWebHostBuilder(builder =>
        {
            builder.ConfigureServices(services => { });
        });
    }

    [Fact]
    public async Task DonationFlow_FormPostAsAnonymousGuest_PersistsDonationAndGeneratesCertificate()
    {
        var client = _factory.CreateClient(new WebApplicationFactoryClientOptions
        {
            AllowAutoRedirect = false,
        });

        // Arrange: fetch the Donate page first, exactly like a real donor
        // would, and grab a project id and the anti-forgery token seeded by
        // DbInitializer, so the POST below is realistic rather than
        // hand-crafted.
        var indexResponse = await client.GetAsync("/Donation");
        Assert.Equal(HttpStatusCode.OK, indexResponse.StatusCode);
        var indexHtml = await indexResponse.Content.ReadAsStringAsync();

        var token = ExtractAntiForgeryToken(indexHtml);
        var cookies = ExtractSetCookieHeaders(indexResponse);

        using var request = new HttpRequestMessage(HttpMethod.Post, "/Donation/Create");
        request.Headers.Add("Cookie", cookies);
        request.Content = new FormUrlEncodedContent(new Dictionary<string, string>
        {
            ["__RequestVerificationToken"] = token,
            ["ProjectId"] = "1",
            ["Amount"] = "500",
            ["Currency"] = "ZAR",
            ["IsRecurring"] = "false",
            ["donateAsGuest"] = "true",
            ["guestName"] = "Integration Test Donor",
        });

        // Act
        var createResponse = await client.SendAsync(request);

        // Assert: the controller redirects to the Certificate action —
        // proof the donation and its TaxCertificate both made it into the
        // database (Certificate() 404s otherwise, see DonationController.cs).
        Assert.Equal(HttpStatusCode.Redirect, createResponse.StatusCode);
        Assert.NotNull(createResponse.Headers.Location);
        Assert.Contains("/Donation/Certificate", createResponse.Headers.Location!.ToString());

        // Follow the redirect and confirm the certificate page renders with
        // a certificate number in the GOTG-<year>-###### format produced by
        // GiftOfTheGivers.Helpers.DonationHelpers.
        using var certRequest = new HttpRequestMessage(HttpMethod.Get, createResponse.Headers.Location);
        certRequest.Headers.Add("Cookie", cookies);
        var certResponse = await client.SendAsync(certRequest);
        var certHtml = await certResponse.Content.ReadAsStringAsync();

        Assert.Equal(HttpStatusCode.OK, certResponse.StatusCode);
        Assert.Contains($"GOTG-{DateTime.UtcNow:yyyy}-", certHtml);

        // Confirm directly against the database too, not just the HTML.
        using var scope = _factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
        var donation = db.Donations
            .OrderByDescending(d => d.DonationId)
            .FirstOrDefault(d => d.DonorDisplayName == "Integration Test Donor");

        Assert.NotNull(donation);
        Assert.True(donation!.IsAnonymous);
        Assert.Equal(500, donation.Amount);
    }

    private static string ExtractAntiForgeryToken(string html)
    {
        const string marker = "name=\"__RequestVerificationToken\" type=\"hidden\" value=\"";
        var start = html.IndexOf(marker, StringComparison.Ordinal);
        if (start < 0)
        {
            // Attribute order can differ depending on the Razor/tag-helper
            // version, so fall back to a more tolerant search.
            const string altMarker = "__RequestVerificationToken\" ";
            start = html.IndexOf(altMarker, StringComparison.Ordinal);
            Assert.True(start >= 0, "Could not locate anti-forgery token in the Donate page HTML.");
            var valueIdx = html.IndexOf("value=\"", start, StringComparison.Ordinal) + "value=\"".Length;
            var altEnd = html.IndexOf('"', valueIdx);
            return html[valueIdx..altEnd];
        }

        start += marker.Length;
        var end = html.IndexOf('"', start);
        return html[start..end];
    }

    private static string ExtractSetCookieHeaders(HttpResponseMessage response)
    {
        if (!response.Headers.TryGetValues("Set-Cookie", out var setCookies))
            return string.Empty;

        return string.Join("; ", setCookies.Select(c => c.Split(';')[0]));
    }
}
