using System.ComponentModel.DataAnnotations;
using GiftOfTheGivers.Helpers;
using Xunit;

namespace GiftOfTheGivers.Tests;

public class DonationHelpersTests
{
    [Fact]
    public void FormatCertificateNumber_ReturnsExpectedFormat()
    {
        var result = DonationHelpers.FormatCertificateNumber(123, new DateTime(2026, 3, 1));
        Assert.Equal("GOTG-2026-000123", result);
    }

    [Fact]
    public void FormatCertificateNumber_ThrowsForInvalidId()
    {
        Assert.Throws<ArgumentOutOfRangeException>(() =>
            DonationHelpers.FormatCertificateNumber(0, DateTime.UtcNow));
    }

    [Fact]
    public void CalculateDonationTotal_SumsAndRoundsCorrectly()
    {
        var total = DonationHelpers.CalculateDonationTotal(new[] { 100.005m, 50.001m });
        Assert.Equal(150.01m, total);
    }

    [Fact]
    public void FormatCurrency_ProducesReadableString()
    {
        var result = DonationHelpers.FormatCurrency(1250, "zar");
        Assert.Equal("ZAR 1,250.00", result);
    }

    [Fact]
    public void FormatCurrency_ThrowsForMissingCurrencyCode()
    {
        Assert.Throws<ArgumentException>(() => DonationHelpers.FormatCurrency(100, ""));
    }

    [Theory]
    [InlineData(1, "GOTG-2026-000001")]
    [InlineData(99999, "GOTG-2026-099999")]
    [InlineData(1234567, "GOTG-2026-1234567")]
    public void FormatCertificateNumber_PadsToSixDigits(int id, string expected)
    {
        Assert.Equal(expected, DonationHelpers.FormatCertificateNumber(id, new DateTime(2026, 6, 1)));
    }

    [Fact]
    public void FormatCertificateNumber_UsesYearOfIssueDate()
    {
        Assert.StartsWith("GOTG-2031-", DonationHelpers.FormatCertificateNumber(5, new DateTime(2031, 1, 1)));
    }

    [Fact]
    public void CalculateDonationTotal_ThrowsForNullInput()
    {
        Assert.Throws<ArgumentNullException>(() => DonationHelpers.CalculateDonationTotal(null!));
    }

    [Fact]
    public void CalculateDonationTotal_MultipleDonations_ReturnsExactSum()
    {
        Assert.Equal(1750.50m, DonationHelpers.CalculateDonationTotal(new[] { 500m, 1000.25m, 250.25m }));
    }

    [Fact]
    public void CalculateDonationTotal_EmptyCollection_ReturnsZero()
    {
        var total = DonationHelpers.CalculateDonationTotal(Array.Empty<decimal>());
        Assert.Equal(0m, total);
    }
}

/// <summary>
/// Part 3, Section A.1: donation-validation tests. These check the
/// <see cref="Donation"/> model's DataAnnotations — the same validation
/// ASP.NET Core MVC model binding runs before <c>DonationController.Create</c>
/// is allowed to touch the database — using a plain <see cref="Validator"/>
/// call rather than spinning up the whole MVC pipeline (that's what the
/// integration test in DonationIntegrationTests.cs is for).
/// </summary>
public class DonationValidationTests
{
    private static IList<ValidationResult> Validate(GiftOfTheGivers.Web.Models.Donation donation)
    {
        var context = new ValidationContext(donation);
        var results = new List<ValidationResult>();
        Validator.TryValidateObject(donation, context, results, validateAllProperties: true);
        return results;
    }

    [Fact]
    public void Donation_WithZeroAmount_FailsValidation()
    {
        var donation = new GiftOfTheGivers.Web.Models.Donation { ProjectId = 1, Amount = 0, Currency = "ZAR" };

        var results = Validate(donation);

        Assert.Contains(results, r => r.MemberNames.Contains(nameof(GiftOfTheGivers.Web.Models.Donation.Amount)));
    }

    [Fact]
    public void Donation_WithNegativeAmount_FailsValidation()
    {
        var donation = new GiftOfTheGivers.Web.Models.Donation { ProjectId = 1, Amount = -50, Currency = "ZAR" };
        Assert.Contains(Validate(donation), r => r.MemberNames.Contains(nameof(GiftOfTheGivers.Web.Models.Donation.Amount)));
    }

    [Fact]
    public void Donation_WithAmountAboveLimit_FailsValidation()
    {
        var donation = new GiftOfTheGivers.Web.Models.Donation { ProjectId = 1, Amount = 1000001, Currency = "ZAR" };
        Assert.NotEmpty(Validate(donation));
    }

    [Fact]
    public void Donation_WithTooLongCurrencyCode_FailsValidation()
    {
        var donation = new GiftOfTheGivers.Web.Models.Donation { ProjectId = 1, Amount = 100, Currency = "RAND" };
        Assert.Contains(Validate(donation), r => r.MemberNames.Contains(nameof(GiftOfTheGivers.Web.Models.Donation.Currency)));
    }

    [Fact]
    public void Donation_WithValidAmount_PassesValidation()
    {
        var donation = new GiftOfTheGivers.Web.Models.Donation { ProjectId = 1, Amount = 250, Currency = "ZAR" };

        var results = Validate(donation);

        Assert.Empty(results);
    }
}
