using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace GiftOfTheGivers.UiTests;

/// <summary>
/// Shared setup for both Selenium scenarios. Reads the site's base URL from
/// the <c>GOTG_BASE_URL</c> environment variable so the same test code can
/// target:
///   - a local <c>dotnet run</c> instance while developing (default),
///   - the pipeline's own locally-started instance during CI (A.2/A.4), or
///   - the live *.azurewebsites.net deployment once Section C.1 is done.
/// </summary>
public abstract class SeleniumTestBase : IDisposable
{
    protected readonly IWebDriver Driver;
    protected readonly string BaseUrl;

    protected SeleniumTestBase()
    {
        BaseUrl = Environment.GetEnvironmentVariable("GOTG_BASE_URL") ?? "http://localhost:5000";

        var options = new ChromeOptions();
        // Headless so this also runs unattended on an Azure Pipelines agent
        // (see azure-pipelines.yml, "UITests" stage) or in a CI container.
        options.AddArgument("--headless=new");
        options.AddArgument("--no-sandbox");
        options.AddArgument("--disable-gpu");
        options.AddArgument("--window-size=1280,900");
        options.AddArgument("--ignore-certificate-errors");

        Driver = new ChromeDriver(options);
        Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
    }

    protected string Url(string relativePath) => $"{BaseUrl.TrimEnd('/')}{relativePath}";

    public void Dispose()
    {
        Driver.Quit();
        Driver.Dispose();
    }
}
