using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Xunit;

namespace GiftOfTheGivers.UiTests;

/// <summary>
/// Part 3, A.4, scenario 1: "employee login". Drives the real login form
/// with the demo Employee account seeded by
/// GiftOfTheGivers.Web/Data/DbInitializer.cs and confirms the
/// role-gated "Dashboard" link (and the Employee-only /Employee/Dashboard
/// page behind it) only appears once signed in as that role — the
/// [Authorize(Roles = "Employee")] behaviour on EmployeeController.
/// </summary>
public class EmployeeLoginTests : SeleniumTestBase
{
    [Fact]
    public void EmployeeLogin_WithSeededDemoAccount_ReachesEmployeeDashboard()
    {
        Driver.Navigate().GoToUrl(Url("/Account/Login"));

        Driver.FindElement(By.Id("Email")).SendKeys("employee@giftofthegivers.local");
        Driver.FindElement(By.Id("Password")).SendKeys("Employee@123");
        Driver.FindElement(By.CssSelector("button[type='submit']")).Click();

        var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(10));

        // After a successful login the navbar's "Dashboard" link (rendered
        // only for the Employee role — see _Layout.cshtml) should appear.
        var dashboardLink = wait.Until(d => d.FindElement(By.LinkText("Dashboard")));
        dashboardLink.Click();

        wait.Until(d => d.Url.Contains("/Employee/Dashboard"));
        var heading = Driver.FindElement(By.TagName("h1")).Text;

        Assert.Contains("Employee dashboard", heading, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("Recent donations", Driver.PageSource);
        Assert.Contains("Volunteer sign-ups", Driver.PageSource);
    }
}
