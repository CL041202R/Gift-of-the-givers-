using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Xunit;

namespace GiftOfTheGivers.UiTests;

/// <summary>
/// Part 3, A.4, scenario 2: "donor anonymous donation". Exercises the
/// donate-as-guest path (no login) end to end through the real browser UI:
/// Donate page -&gt; guest checkbox path -&gt; Certificate page with a
/// generated GOTG-##### tax certificate number.
/// </summary>
public class AnonymousDonationTests : SeleniumTestBase
{
    [Fact]
    public void AnonymousDonor_CanDonateAsGuest_AndSeesGeneratedCertificate()
    {
        Driver.Navigate().GoToUrl(Url("/Donation"));

        // Not logged in, so the guest panel (with the hidden
        // donateAsGuest=true field) is rendered — see Donation/Index.cshtml.
        var amount = Driver.FindElement(By.Id("Amount"));
        amount.Clear();
        amount.SendKeys("750");

        // Pick ZAR by clicking the <option> directly (no extra Selenium package needed).
        Driver.FindElement(By.CssSelector("#Currency option[value='ZAR']")).Click();

        Driver.FindElement(By.Name("guestName")).SendKeys("Selenium Test Donor");
        Driver.FindElement(By.CssSelector("button[type='submit']")).Click();

        var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(10));
        wait.Until(d => d.Url.Contains("/Donation/Certificate"));

        var pageText = Driver.FindElement(By.TagName("body")).Text;

        Assert.Contains("Selenium Test Donor", pageText);
        Assert.Contains($"GOTG-{DateTime.UtcNow:yyyy}-", pageText);
    }
}
