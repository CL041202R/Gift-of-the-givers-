using System.Text.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;

namespace GiftOfTheGivers.Functions;

// Connects to the prototype as described in Section A.1: "When an employee
// posts an update, the function logs it in Azure Storage." This keeps an
// independent, append-only audit trail of every relief-project update in
// Blob Storage, separate from the SQL database — useful during a disaster
// if the primary database is ever under heavy write load.
public class LogProjectUpdateFunction
{
    private readonly ILogger _logger;

    public LogProjectUpdateFunction(ILoggerFactory loggerFactory)
    {
        _logger = loggerFactory.CreateLogger<LogProjectUpdateFunction>();
    }

    public record ProjectUpdateRequest(string ProjectName, string UpdateText, string PostedBy);

    [Function("LogProjectUpdate")]
    [BlobOutput("project-updates/{rand-guid}.json", Connection = "AzureWebJobsStorage")]
    public async Task<string> Run(
        [HttpTrigger(AuthorizationLevel.Function, "post", Route = "LogProjectUpdate")] HttpRequestData req,
        FunctionContext context)
    {
        _logger.LogInformation("LogProjectUpdate function triggered.");

        using var reader = new StreamReader(req.Body);
        var body = await reader.ReadToEndAsync();
        var update = JsonSerializer.Deserialize<ProjectUpdateRequest>(body, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

        var logEntry = new
        {
            update?.ProjectName,
            update?.UpdateText,
            update?.PostedBy,
            LoggedAtUtc = DateTime.UtcNow,
        };

        // Returned string becomes the blob content via the [BlobOutput] binding above.
        return JsonSerializer.Serialize(logEntry, new JsonSerializerOptions { WriteIndented = true });
    }
}
