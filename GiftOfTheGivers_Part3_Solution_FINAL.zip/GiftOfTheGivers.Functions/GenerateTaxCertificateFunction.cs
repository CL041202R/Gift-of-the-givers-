using System.Text.Json;
using GiftOfTheGivers.Helpers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace GiftOfTheGivers.Functions;

// Connects to the prototype as described in Section A.1: "When a donor
// completes a donation form, the function generates a dummy tax certificate."
// In Part 1 this logic lived inline in DonationController; here it is a
// standalone, independently deployable/scalable service that the web app
// (or, later, a payment webhook) can call over HTTP.
public class GenerateTaxCertificateFunction
{
    private readonly ILogger _logger;

    public GenerateTaxCertificateFunction(ILoggerFactory loggerFactory)
    {
        _logger = loggerFactory.CreateLogger<GenerateTaxCertificateFunction>();
    }

    public record CertificateRequest(int DonationId, decimal Amount, string Currency, string DonorName);
    public record CertificateResponse(string CertificateNumber, string FormattedAmount, DateTime IssuedAtUtc);

    [Function("GenerateTaxCertificate")]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Function, "post", Route = "GenerateTaxCertificate")] HttpRequest req)
    {
        _logger.LogInformation("GenerateTaxCertificate function triggered.");

        CertificateRequest? request;
        try
        {
            using var reader = new StreamReader(req.Body);
            var body = await reader.ReadToEndAsync();
            request = JsonSerializer.Deserialize<CertificateRequest>(body, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        }
        catch (JsonException)
        {
            return new BadRequestObjectResult("Request body must be valid JSON.");
        }

        if (request is null || request.DonationId <= 0 || request.Amount <= 0 || string.IsNullOrWhiteSpace(request.Currency))
            return new BadRequestObjectResult("DonationId, Amount and Currency are required.");

        var issuedAt = DateTime.UtcNow;
        var response = new CertificateResponse(
            CertificateNumber: DonationHelpers.FormatCertificateNumber(request.DonationId, issuedAt),
            FormattedAmount: DonationHelpers.FormatCurrency(request.Amount, request.Currency),
            IssuedAtUtc: issuedAt);

        return new OkObjectResult(response);
    }
}
