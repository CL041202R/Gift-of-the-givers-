# Part 2 — Disaster Alleviation Foundation Implementation

This solution extends the Part 1 prototype with:

- **`GiftOfTheGivers.Helpers`** — shared utility class library, packaged as a NuGet package (Section D)
- **`GiftOfTheGivers.Functions`** — Azure Functions project with two HTTP-triggered functions (Section A)
- **`GiftOfTheGivers.Tests`** — xUnit tests for the helper library, run by the CI pipeline (Section C)
- **`GiftOfTheGivers.Web`** — the Part 1 web app, now consuming `GiftOfTheGivers.Helpers` for certificate formatting
- **`azure-pipelines.yml`** — the CI build pipeline definition (Section C)
- **`nuget.config.template`** — template for connecting to your Azure Artifacts feed (Section D). **Not active until you rename it** — see Section D.1 below for why.

Everything below that can be built as code has been built and is ready to run. The
steps that must happen inside **your team's own Azure DevOps organisation** (creating
the repo, pushing, branching, wiring up the pipeline and the Artifacts feed) are
marked **ACTION (your team)** — take the listed screenshots for your submission at
each one.

---

## Section A: Extending the Web App with Azure Functions

Already built:
- `GenerateTaxCertificateFunction` — `POST /api/GenerateTaxCertificate` with body
  `{ "donationId": 1, "amount": 250, "currency": "ZAR", "donorName": "Jane Donor" }`,
  returns a certificate number and formatted amount using the same
  `GiftOfTheGivers.Helpers` logic the web app uses.
- `LogProjectUpdateFunction` — `POST /api/LogProjectUpdate` with body
  `{ "projectName": "KZN Flood Response 2026", "updateText": "...", "postedBy": "employee@giftofthegivers.local" }`,
  writes a timestamped JSON blob to the `project-updates` container via a Blob
  output binding.

### A.2 Run and test locally

1. Install [Azure Functions Core Tools](https://learn.microsoft.com/azure/azure-functions/functions-run-local) and [Azurite](https://learn.microsoft.com/azure/storage/common/storage-use-azurite) (or use the Azurite VS Code extension / the storage emulator built into Visual Studio).
2. Start Azurite, then in Visual Studio press **F5** on the `GiftOfTheGivers.Functions` project (or `func start` from that folder).
3. Test with Postman or a browser: `POST http://localhost:7071/api/GenerateTaxCertificate` with the JSON body above.
4. **ACTION (your team):** screenshot the function running locally in the console/VS output, and the Postman request/response.

### A.3 Deploy to Azure

**ACTION (your team):** right-click `GiftOfTheGivers.Functions` in Visual Studio > **Publish** > **Azure** > **Azure Function App (Linux)** > create a new Function App > Publish. Screenshot the publish succeeding and the live function URL responding (append your function key: `?code=...`, shown in the Azure Portal under the function's **Get Function URL**).

---

## Section B: Managing Code with Azure Repos Git

**ACTION (your team) — all of Section B happens in your own Azure DevOps org:**

1. In Azure DevOps, open your project (the same one from Part 1) > **Repos** > if empty, note the clone URL.
2. In Visual Studio: **Git > Clone Repository**, paste the URL, OR if you already have this solution open, **Git > Create Git Repository** and connect it to the existing Azure Repos remote (`git remote add origin <url>` from the Developer PowerShell also works).
3. Commit everything (`git add .`, `git commit -m "Part 2: Functions, Helpers, Tests, pipeline"`) and push to `main`. Screenshot the repo now showing all four projects, and the commit history (**Repos > Commits**).
4. Create two branches from Visual Studio's **Git Changes** pane (or `git checkout -b donations-feature` / `git checkout -b volunteer-feature`):
   - `donations-feature` — each teammate working on donations makes a small commit here (e.g. a UI tweak to `Views/Donation/Index.cshtml`).
   - `volunteer-feature` — same, for `Views/Volunteer/Index.cshtml`.
5. Every group member commits at least one change to one of the branches.
6. Merge each branch back into `main` using Visual Studio's Git tools (**Git > Manage Branches**, right-click branch > **Merge From**), or via a Pull Request in Azure Repos (recommended — it also gives you a clean screenshot of the merge and the CI check running).
7. Screenshot: the branch list, at least two commits from different branches, and the completed merge/PR.

---

## Section C: Continuous Builds with Azure Pipelines

The pipeline definition is already written for you: **`azure-pipelines.yml`** at the
solution root. It restores all projects, builds the whole solution, and runs the
`GiftOfTheGivers.Tests` project, publishing the test results.

**ACTION (your team):**

1. In Azure DevOps: **Pipelines > New Pipeline > Azure Repos Git** > select your repo.
2. Choose **Existing Azure Pipelines YAML file** > branch `main` > path `/azure-pipelines.yml` > **Continue** > **Run**.
3. Screenshot the YAML pipeline configuration screen and the pipeline succeeding in Azure DevOps (green checkmark, with the Restore/Build/Test steps expanded).
4. **C.2:** make a small code change locally (e.g. edit a label in a view), commit, and push to `main`. Screenshot the pipeline automatically triggering within a minute or two, and completing successfully.

---

## Section D: Package Hosting with Azure Artifacts

`GiftOfTheGivers.Helpers` is already set up as a packable project (see its `.csproj` —
`IsPackable`, `PackageId`, `Version`, `Authors`, `Description` are all set).

### D.1 Pack and publish

**ACTION (your team):**

1. In Azure DevOps: **Artifacts > Create Feed** — name it e.g. `GiftOfTheGiversFeed`, scope it to your project.
2. Locally, pack the library:
   ```
   cd GiftOfTheGivers.Helpers
   dotnet pack -c Release -o ./nupkg
   ```
   This produces `nupkg/GiftOfTheGivers.Helpers.1.0.0.nupkg`.
3. Get a **Personal Access Token** (Azure DevOps user settings > Personal Access Tokens) with **Packaging (Read & write)** scope, then rename `nuget.config.template` at the solution root to `nuget.config` and fill in `YOUR_ORG`, `YOUR_PROJECT`, `YOUR_FEED`, `YOUR_PERSONAL_ACCESS_TOKEN`.
   > **Important:** the solution ships with this file named `nuget.config.template` (not `nuget.config`) on purpose. Once a real `nuget.config` exists in the solution, NuGet uses *only* the sources listed in it — so if you rename it before filling in your real feed details, restore will fail for every package (you'll see `NU1100` errors) because the placeholder feed URL doesn't exist. Only rename it once you've filled in your actual org/project/feed/PAT.
4. Push the package to your feed:
   ```
   dotnet nuget push "nupkg/GiftOfTheGivers.Helpers.1.0.0.nupkg" --source "GiftOfTheGiversFeed" --api-key az
   ```
   (Azure Artifacts ignores the literal API key value when using a PAT via `nuget.config` — `az` is just a placeholder the CLI requires.)
5. Screenshot the feed in Azure DevOps showing the published package, and the successful `dotnet nuget push` output.

### D.2 Consume the package from the feed

Right now `GiftOfTheGivers.Web` references `GiftOfTheGivers.Helpers` as a
**ProjectReference** so the solution builds immediately with no external
dependency (see the comment in `GiftOfTheGivers.Web.csproj`). To satisfy D.2 exactly
as specified — consuming it as a published NuGet package rather than a project
reference — **ACTION (your team):**

1. In `GiftOfTheGivers.Web.csproj`, delete the `<ProjectReference Include="..\GiftOfTheGivers.Helpers\..." />` line and add:
   ```xml
   <PackageReference Include="GiftOfTheGivers.Helpers" Version="1.0.0" />
   ```
2. Run `dotnet restore` — with `nuget.config` pointing at your feed, it will resolve the package from Azure Artifacts instead of the local project.
3. Build and run the web app, make a donation, and confirm the certificate page still renders — this proves the app is now using the *packaged* helper, not the local project.
4. Screenshot: the updated `.csproj`, the successful restore/build pulling from your feed, and the working certificate page.

---

## Submission checklist (from the brief)

- [ ] Screenshots of the updated Visual Studio solution (web app + function project + helper library)
- [ ] Evidence of Azure Repos integration: commits, branches, merges
- [ ] Evidence of the Azure Pipeline building automatically on commit
- [ ] Evidence of NuGet package creation, publishing, and consumption from the feed
- [ ] Short reflection (per group) on which member worked on which part
