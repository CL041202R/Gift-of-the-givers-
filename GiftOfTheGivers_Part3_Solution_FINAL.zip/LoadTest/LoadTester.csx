// Part 3, Section A.3 — fallback load tester (no k6 required).
// Usage: dotnet script LoadTester.csx -- <baseUrl>
// Example: dotnet script LoadTester.csx -- http://localhost:5000

using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Net.Http;
using System.Threading.Tasks;

var baseUrl = Args.Count > 0 ? Args[0] : "http://localhost:5000";
const int concurrentUsers = 5;      // per the brief
var testDuration = TimeSpan.FromSeconds(30);
var paths = new[] { "/", "/Donation", "/Volunteer" };

Console.WriteLine($"Load testing {baseUrl} with {concurrentUsers} concurrent users for {testDuration.TotalSeconds}s...");

using var client = new HttpClient { BaseAddress = new Uri(baseUrl), Timeout = TimeSpan.FromSeconds(10) };
var results = new ConcurrentBag<(bool success, long elapsedMs)>();
var stopAt = DateTime.UtcNow + testDuration;

var users = Enumerable.Range(1, concurrentUsers).Select(async userId =>
{
    var random = new Random(userId);
    while (DateTime.UtcNow < stopAt)
    {
        var path = paths[random.Next(paths.Length)];
        var sw = Stopwatch.StartNew();
        try
        {
            var response = await client.GetAsync(path);
            sw.Stop();
            results.Add((response.IsSuccessStatusCode, sw.ElapsedMilliseconds));
        }
        catch
        {
            sw.Stop();
            results.Add((false, sw.ElapsedMilliseconds));
        }
        await Task.Delay(1000); // mimic a human pausing between page loads
    }
});

await Task.WhenAll(users);

var all = results.ToList();
var successes = all.Count(r => r.success);
var failures = all.Count - successes;
var avgMs = all.Count > 0 ? all.Average(r => r.elapsedMs) : 0;
var maxMs = all.Count > 0 ? all.Max(r => r.elapsedMs) : 0;

Console.WriteLine();
Console.WriteLine("=== Load test results ===");
Console.WriteLine($"Total requests:      {all.Count}");
Console.WriteLine($"Successful:          {successes}");
Console.WriteLine($"Failed:              {failures}");
Console.WriteLine($"Average response ms: {avgMs:F0}");
Console.WriteLine($"Max response ms:     {maxMs}");
Console.WriteLine($"Requests/sec:        {all.Count / testDuration.TotalSeconds:F2}");
