// Part 3, Section A.3: Load and Stress Testing.
//
// Simulates the brief's "5 concurrent users" browsing and donating on the
// site. Run with k6 (https://k6.io — free, no Azure resource required):
//
//   k6 run -e BASE_URL=https://your-app.azurewebsites.net LoadTest/donation-load-test.js
//
// (Omit -e BASE_URL to default to a local `dotnet run` instance.)
//
// ACTION (your team): run this against your deployed App Service (Section
// C.1) once it exists, and screenshot the summary k6 prints at the end
// (requests/sec, p95 latency, failure rate) for your A.3 submission.

import http from 'k6/http';
import { check, sleep } from 'k6';

const BASE_URL = __ENV.BASE_URL || 'http://localhost:5000';

export const options = {
  scenarios: {
    five_concurrent_users: {
      executor: 'constant-vus',
      vus: 5,          // 5 concurrent users, per the brief
      duration: '30s',
    },
  },
  thresholds: {
    http_req_failed: ['rate<0.01'],   // fewer than 1% of requests should fail
    http_req_duration: ['p(95)<1500'], // 95% of requests should complete under 1.5s
  },
};

export default function () {
  // A realistic small "browse the site" journey per virtual user, rather
  // than hammering a single endpoint.
  const home = http.get(`${BASE_URL}/`);
  check(home, { 'home page loads (200)': (r) => r.status === 200 });
  sleep(1);

  const donatePage = http.get(`${BASE_URL}/Donation`);
  check(donatePage, { 'donate page loads (200)': (r) => r.status === 200 });
  sleep(1);

  const volunteerPage = http.get(`${BASE_URL}/Volunteer`);
  check(volunteerPage, { 'volunteer page loads (200)': (r) => r.status === 200 });
  sleep(1);
}
