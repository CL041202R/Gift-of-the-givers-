# Load and Stress Testing (Part 3, Section A.3)

Two ways to run the required 5-concurrent-user load test — use whichever is
easier to install on your machine. Both hit the same three pages (Home,
Donate, Volunteer) with 5 simulated users for ~30 seconds.

## Option A — k6 (recommended)

1. Install k6: https://grafana.com/docs/k6/latest/set-up/install-k6/
   (Windows: `winget install k6 --source winget` or `choco install k6`)
2. Run your app locally (`dotnet run` from `GiftOfTheGivers.Web`) or note
   your deployed App Service URL.
3. From the solution root:
   ```
   k6 run LoadTest/donation-load-test.js
   # or against the deployed site:
   k6 run -e BASE_URL=https://<your-app>.azurewebsites.net LoadTest/donation-load-test.js
   ```
4. **ACTION (your team):** screenshot the summary table k6 prints
   (`http_req_duration`, `http_req_failed`, requests/sec, VUs=5) for your
   submission.

## Option B — built-in .NET console load tester (no extra install)

If you'd rather not install k6, `LoadTester.csx` is a small C# script that
does the same thing with only the .NET SDK you already have.

```
cd LoadTest
dotnet script LoadTester.csx -- http://localhost:5000
```

(If `dotnet script` isn't installed: `dotnet tool install -g dotnet-script`
once, then the command above works. Alternatively paste `LoadTester.csx`'s
`Main` logic into a throwaway Console App project and `dotnet run` it.)

**ACTION (your team):** screenshot the console output (average/median
response time, success/failure counts) for your submission.

## What to write up for A.3

In your report, alongside the screenshots, briefly note:

- What the test simulated (5 concurrent users browsing Home/Donate/Volunteer
  for 30 seconds).
- The results (average response time, error rate, requests/sec).
- Whether the prototype's App Service tier (Free/Basic/B1) coped, and what
  you'd change for a real production load — e.g. scaling out to more
  instances, adding a CDN for static assets, or moving the database off the
  Free-tier SQL Database (ties back to Part 1, Section 2.1's discussion of
  scalability).
