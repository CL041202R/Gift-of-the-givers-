# Part 3 Submission Runbook — do these in order

## Phase 1 — Local (30 min, no Azure needed)
1. Open `GiftOfTheGivers.Web.sln` in Visual Studio. **Build > Rebuild Solution**. Fix any error before continuing (send it to Claude if stuck).
2. Test Explorer > Run All in `GiftOfTheGivers.Tests`. 📸 **S1** all green (unit). 📸 **S2** integration tests green (expand the tree).
3. Terminal 1: `cd GiftOfTheGivers.Web && dotnet run --urls http://localhost:5000`. Terminal 2: `dotnet test GiftOfTheGivers.UiTests`. 📸 **S3** passing Selenium results. (Temporarily remove `--headless=new` in `SeleniumTestBase.cs` and record a short screen capture of the browser being driven — extra evidence.)
4. Install k6, run `k6 run LoadTest/donation-load-test.js`. 📸 **S4** summary. Copy the numbers into the report's A.3 table.
5. While the app runs, take the **user-manual screenshots** (see list at bottom).

## Phase 2 — Azure (45 min)
6. Azure Portal > Cloud Shell (Bash). Upload `deploy/azure-setup.sh`, edit the password, run `bash azure-setup.sh`. Save the printed values.
7. Azure DevOps: push the solution to your Repo (`main`). Project Settings > Service connections > New > Azure Resource Manager (automatic). Note its name.
8. Pipelines > New pipeline > Azure Repos Git > Existing YAML > `/azure-pipelines.yml`. Variables: `azureSubscription`, `resourceGroupName`, `webAppName`, `functionAppName`, `sqlServerName`, `sqlDatabaseName`, `sqlAdminUser`, `sqlAdminPassword` (secret), `SqlConnectionString` (secret). First run will ask you to **permit** the environments/service connection: approve.
9. Make a feature-branch commit (e.g. edit a comment) and push: 📸 **S5** pipeline triggered by a non-main branch (proves "every commit"); 📸 **S6** YAML; 📸 **S7** `dotnet test` log; 📸 **S8** Tests tab with counts.
10. Merge/push to `main`: 📸 **S9** three stages green; 📸 **S10** DeployWebApp success; 📸 **S11** live site `https://<webAppName>.azurewebsites.net` (show URL bar); 📸 **S12** DeployFunctions; 📸 **S13** Function App > Functions list; 📸 **S14** test call: POST `{"donationId":7,"amount":250,"currency":"ZAR","donorName":"Test"}` to the function (Portal > function > Code + Test > Test/Run, or Postman with the function key) showing the JSON response; 📸 **S15** DeploySqlSchema log.
11. Portal > SQL database > Query editor: paste `Database/01_VerifySchema.sql`. 📸 **S16** tables + index + view. Make one donation on the live site first, then run `SELECT * FROM vw_ProjectDonationTotals` 📸 **S17**.
12. Re-run load test against the live URL: `k6 run -e BASE_URL=https://<webAppName>.azurewebsites.net LoadTest/donation-load-test.js` 📸 **S18**. Use *this* result in A.3.
13. Optional but strong: run Selenium against the live site: `set GOTG_BASE_URL=https://<webAppName>.azurewebsites.net` then `dotnet test GiftOfTheGivers.UiTests` 📸 **S19**.

## Phase 3 — Documents
14. Paste S1–S19 over the dashed red boxes in `GiftOfTheGivers_Part3_Report.docx`; replace every `[...]`. Search the doc for `[` and `fill in` — none may remain.
15. `UserManual.docx` screenshots: login (employee, donor), register, post update (Employee > Dashboard > Post update), donation (guest, once-off, recurring monthly, a non-ZAR currency), certificate page, volunteer form. One short caption per screenshot, plain language.
16. `TeamContributionReport.docx`: real names, roles, and per person 2–3 evidence links (Azure Repos commit URLs, Boards work items, pipeline runs). Everyone must have commits — make sure each member has pushed something real **before** submitting.
17. Final check against the brief: every bullet in A.1–D has a screenshot or code snippet in the report.

## Likely viva / lecturer questions (be able to answer)
- Difference between unit and integration tests? Which of yours is which?
- Why does the integration test compare the Function's number to the database's?
- What does `WebApplicationFactory` do? Why `public partial class Program`?
- Why does `Deploy` depend on `Build_And_Test`? What happens if a test fails?
- Why is the SQL script idempotent? Why are secrets pipeline variables?
- What would you change for real disaster traffic (scale-out, CDN, Application Insights, SQL tier)?
- Why `continueOnError` on UI tests?
