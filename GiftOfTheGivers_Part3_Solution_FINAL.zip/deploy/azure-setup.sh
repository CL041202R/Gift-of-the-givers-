#!/usr/bin/env bash
# One-time Azure resource creation for Part 3 (Sections C.1-C.3).
# Run in Azure Cloud Shell (Bash) at https://shell.azure.com - no install needed.
# EDIT the five values below first. Names of web/function/sql/storage must be globally unique.
set -euo pipefail

SUFFIX="gotg$RANDOM"                    # makes names unique; note the output
RG="rg-giftofthegivers"
LOCATION="southafricanorth"             # or westeurope if quota is unavailable
SQL_ADMIN="gotgadmin"
SQL_PASSWORD='ChangeMe-Str0ng-Passw0rd!'   # CHANGE THIS

PLAN="plan-gotg-b1"
WEBAPP="gotg-web-$SUFFIX"
FUNCAPP="gotg-func-$SUFFIX"
SQLSERVER="gotg-sql-$SUFFIX"
SQLDB="GiftOfTheGivers"
STORAGE="gotgstore$RANDOM"

az group create -n $RG -l $LOCATION

# SQL: logical server + Basic-tier database (cheapest; fits "within B1 limits")
az sql server create -g $RG -n $SQLSERVER -l $LOCATION -u $SQL_ADMIN -p "$SQL_PASSWORD"
az sql db create -g $RG -s $SQLSERVER -n $SQLDB --edition Basic
az sql server firewall-rule create -g $RG -s $SQLSERVER -n AllowAzureServices \
   --start-ip-address 0.0.0.0 --end-ip-address 0.0.0.0

# App Service (Linux, B1) + web app on .NET 8
az appservice plan create -g $RG -n $PLAN --is-linux --sku B1
az webapp create -g $RG -p $PLAN -n $WEBAPP --runtime "DOTNETCORE:8.0"

CONN="Server=tcp:$SQLSERVER.database.windows.net,1433;Database=$SQLDB;User ID=$SQL_ADMIN;Password=$SQL_PASSWORD;Encrypt=true;TrustServerCertificate=false;"
az webapp config connection-string set -g $RG -n $WEBAPP -t SQLAzure --settings DefaultConnection="$CONN"

# Function App (Linux, .NET 8 isolated, consumption) + storage
az storage account create -g $RG -n $STORAGE -l $LOCATION --sku Standard_LRS
az functionapp create -g $RG -n $FUNCAPP --storage-account $STORAGE \
   --consumption-plan-location $LOCATION --runtime dotnet-isolated --runtime-version 8.0 \
   --functions-version 4 --os-type Linux

echo "=============== COPY THESE INTO AZURE DEVOPS PIPELINE VARIABLES ==============="
echo "azureSubscription  = <your service connection name>"
echo "resourceGroupName  = $RG"
echo "webAppName         = $WEBAPP"
echo "functionAppName    = $FUNCAPP"
echo "sqlServerName      = $SQLSERVER"
echo "sqlDatabaseName    = $SQLDB"
echo "sqlAdminUser       = $SQL_ADMIN"
echo "sqlAdminPassword   = (the password above)   <- mark as SECRET"
echo "SqlConnectionString= $CONN                   <- mark as SECRET"
echo "Live site          = https://$WEBAPP.azurewebsites.net"
