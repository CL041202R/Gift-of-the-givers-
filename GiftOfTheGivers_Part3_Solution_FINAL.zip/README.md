# Gift of the Givers Foundation — Web Application Prototype

ASP.NET Core 8 MVC prototype for **Part 1, Section C** of the Portfolio of Evidence.
It runs with zero setup (an in-memory database is used by default) and demonstrates
the branding, navigation, authentication/roles, donation flow, and volunteer flow
required by the brief.

## Running locally

1. Open `GiftOfTheGivers.Web.sln` in Visual Studio 2022 (Workload: **ASP.NET and web development**), or from the CLI:
   ```
   cd GiftOfTheGivers.Web
   dotnet restore
   dotnet run
   ```
2. Browse to the URL shown in the console (e.g. `https://localhost:5001`).
3. The app seeds two demo relief projects and one demo Employee account automatically on first run:
   - **Employee login:** `employee@giftofthegivers.local` / `Employee@123`
   - Register a new account through the site to get a **Donor** account.

## What maps to the mark scheme (Section C.2)

| Requirement | Where it is |
|---|---|
| Logo & header showing Foundation identity | `Views/Shared/_Layout.cshtml` (navbar with brand mark) |
| Navigation bar (Home, About, Donate, Volunteer, Contact) | `Views/Shared/_Layout.cshtml` |
| Responsive Bootstrap layout | Bootstrap 5 via CDN in `_Layout.cshtml`, `wwwroot/css/site.css` |
| ASP.NET Identity authentication | `Data/ApplicationUser.cs`, `Controllers/AccountController.cs`, `Program.cs` |
| Two roles (Employee, Donor) | Seeded in `Data/DbInitializer.cs`; role-gating via `[Authorize(Roles="Employee")]` in `Controllers/EmployeeController.cs` |
| Donation: one-time/recurring, currency choice | `Views/Donation/Index.cshtml`, `Models/DomainModels.cs` (`Donation`) |
| Guest ("anonymous") donation | `donateAsGuest` handling in `Controllers/DonationController.cs` |
| Placeholder tax certificate on donation | `Controllers/DonationController.cs` (`Create` action) + `Views/Donation/Certificate.cshtml` |
| Volunteer sign-up form (name, skills, availability) | `Views/Volunteer/Index.cshtml`, `Models/DomainModels.cs` (`VolunteerSignup`) |
| Employee dashboard (donations, volunteer sign-ups, project updates) | `Controllers/EmployeeController.cs`, `Views/Employee/Dashboard.cshtml` |
| Minimal data persistence at prototype stage | `Program.cs` — EF Core InMemory by default, one-line switch to Azure SQL |

## Connecting it to your Azure SQL Database (Section B)

Once your group has created the Azure SQL Database from the Part 1 Section B schema,
add the connection string to `appsettings.json`:

```json
"ConnectionStrings": {
  "DefaultConnection": "Server=tcp:<your-server>.database.windows.net,1433;Database=<your-db>;User ID=<user>;Password=<password>;Encrypt=true;"
}
```

`Program.cs` automatically switches from the in-memory database to `UseSqlServer` as
soon as this connection string is non-empty. Then run EF Core migrations:

```
dotnet ef migrations add InitialCreate
dotnet ef database update
```

## Deploying to Azure App Services (Section 3.3)

This step must be done from your own Azure subscription — it can't be done on your
behalf here. In Visual Studio: right-click the `GiftOfTheGivers.Web` project **>
Publish > Azure > Azure App Service (Linux) >** create a new App Service (Free/Basic
tier is enough for a prototype) **> Publish**. Screenshot the publish profile, the
deployment succeeding, and the live `*.azurewebsites.net` site for your submission.

## Notes

- This is a prototype: donation and volunteer data persistence is intentionally
  minimal per the brief ("data persistence can be minimal... full logic developed
  in Part 2").
- The tax certificate is generated inline in `DonationController` for the
  prototype; the brief's Part 2 moves this into an Azure Function.
- Not affiliated with the official Gift of the Givers Foundation.
