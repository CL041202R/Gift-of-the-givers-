using System.Globalization;

namespace GiftOfTheGivers.Helpers;

/// <summary>
/// Shared utility methods used by both the web app and the Azure Function
/// (Section A) so certificate-number formatting stays identical wherever
/// a certificate is generated. Packaged as a NuGet package via Azure
/// Artifacts — see Section D of the Part 2 brief.
/// </summary>
public static class DonationHelpers
{
    /// <summary>
    /// Builds a consistent tax certificate number, e.g. "GOTG-2026-000123".
    /// </summary>
    public static string FormatCertificateNumber(int donationId, DateTime issuedAtUtc)
    {
        if (donationId <= 0)
            throw new ArgumentOutOfRangeException(nameof(donationId), "Donation id must be a positive number.");

        return $"GOTG-{issuedAtUtc:yyyy}-{donationId:D6}";
    }

    /// <summary>
    /// Sums a set of donation amounts. Centralised here so rounding rules
    /// only need to change in one place if the Foundation's finance team
    /// adjusts them later.
    /// </summary>
    public static decimal CalculateDonationTotal(IEnumerable<decimal> amounts)
    {
        ArgumentNullException.ThrowIfNull(amounts);
        return Math.Round(amounts.Sum(), 2, MidpointRounding.AwayFromZero);
    }

    /// <summary>
    /// Formats an amount with its ISO currency code for display, e.g. "ZAR 1,250.00".
    /// </summary>
    public static string FormatCurrency(decimal amount, string currencyCode)
    {
        if (string.IsNullOrWhiteSpace(currencyCode))
            throw new ArgumentException("Currency code is required.", nameof(currencyCode));

        // InvariantCulture so output is identical on every machine (an en-ZA PC
        // would otherwise render "1 250,00" and break the tests / certificates).
        return $"{currencyCode.ToUpperInvariant()} {amount.ToString("N2", CultureInfo.InvariantCulture)}";
    }
}
