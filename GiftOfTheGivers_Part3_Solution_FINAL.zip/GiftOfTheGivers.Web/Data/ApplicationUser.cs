using Microsoft.AspNetCore.Identity;

namespace GiftOfTheGivers.Web.Data;

// Extends the built-in Identity user with the extra profile field
// the brief asks for (FullName), while Email/PasswordHash etc. are
// already provided by IdentityUser. This maps to the Users entity
// in the Part 1 Section B database design.
public class ApplicationUser : IdentityUser
{
    public string FullName { get; set; } = string.Empty;
}
