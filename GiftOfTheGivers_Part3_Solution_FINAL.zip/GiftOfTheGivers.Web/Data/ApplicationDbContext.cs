using GiftOfTheGivers.Web.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace GiftOfTheGivers.Web.Data;

public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options) { }

    public DbSet<ReliefProject> ReliefProjects => Set<ReliefProject>();
    public DbSet<Donation> Donations => Set<Donation>();
    public DbSet<TaxCertificate> TaxCertificates => Set<TaxCertificate>();
    public DbSet<VolunteerSignup> VolunteerSignups => Set<VolunteerSignup>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        // Explicit primary keys: these entities' key properties don't
        // follow EF Core's "<ClassName>Id" naming convention (e.g.
        // ReliefProject's key is ProjectId, not ReliefProjectId), so EF
        // Core can't auto-detect them and throws InvalidOperationException
        // ("requires a primary key to be defined") without this.
        builder.Entity<ReliefProject>().HasKey(p => p.ProjectId);
        builder.Entity<TaxCertificate>().HasKey(c => c.CertificateId);
        builder.Entity<VolunteerSignup>().HasKey(v => v.VolunteerId);

        builder.Entity<Donation>()
            .HasOne(d => d.Project)
            .WithMany()
            .HasForeignKey(d => d.ProjectId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.Entity<TaxCertificate>()
            .HasOne(c => c.Donation)
            .WithOne(d => d.Certificate)
            .HasForeignKey<TaxCertificate>(c => c.DonationId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.Entity<TaxCertificate>()
            .HasIndex(c => c.DonationId)
            .IsUnique();

        builder.Entity<TaxCertificate>()
            .HasIndex(c => c.CertificateNumber)
            .IsUnique();

        builder.Entity<VolunteerSignup>()
            .HasOne(v => v.Project)
            .WithMany()
            .HasForeignKey(v => v.ProjectId)
            .OnDelete(DeleteBehavior.SetNull);

        // Indexes that support the most common lookups (see Section 2.3
        // of the planning report: donations-per-project, volunteer matching).
        builder.Entity<Donation>().HasIndex(d => new { d.ProjectId, d.DonatedAt });
        builder.Entity<VolunteerSignup>().HasIndex(v => v.ProjectId);
    }
}
