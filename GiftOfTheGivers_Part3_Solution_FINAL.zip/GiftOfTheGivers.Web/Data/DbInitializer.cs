using GiftOfTheGivers.Web.Models;
using Microsoft.AspNetCore.Identity;

namespace GiftOfTheGivers.Web.Data;

public static class DbInitializer
{
    public static readonly string[] Roles = { "Employee", "Donor" };

    public static async Task SeedAsync(IServiceProvider services)
    {
        var context = services.GetRequiredService<ApplicationDbContext>();
        var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
        var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();

        await context.Database.EnsureCreatedAsync();

        foreach (var role in Roles)
        {
            if (!await roleManager.RoleExistsAsync(role))
                await roleManager.CreateAsync(new IdentityRole(role));
        }

        // Seed one demo Employee account so a marker/reviewer can log
        // straight into the employee dashboard without registering.
        const string employeeEmail = "employee@giftofthegivers.local";
        if (await userManager.FindByEmailAsync(employeeEmail) is null)
        {
            var employee = new ApplicationUser
            {
                UserName = employeeEmail,
                Email = employeeEmail,
                FullName = "Demo Employee",
                EmailConfirmed = true,
            };
            var result = await userManager.CreateAsync(employee, "Employee@123");
            if (result.Succeeded)
                await userManager.AddToRoleAsync(employee, "Employee");
        }

        if (!context.ReliefProjects.Any())
        {
            context.ReliefProjects.AddRange(
                new ReliefProject
                {
                    ProjectName = "KZN Flood Response 2026",
                    Description = "Emergency shelter, clean water and food parcels for communities displaced by flooding in KwaZulu-Natal.",
                    Location = "KwaZulu-Natal, South Africa",
                    Status = "Active",
                    StartDate = DateTime.UtcNow.AddDays(-10),
                },
                new ReliefProject
                {
                    ProjectName = "Eastern Cape Drought Relief",
                    Description = "Water tankering and borehole rehabilitation for drought-affected rural communities.",
                    Location = "Eastern Cape, South Africa",
                    Status = "Active",
                    StartDate = DateTime.UtcNow.AddDays(-30),
                }
            );
            await context.SaveChangesAsync();
        }
    }
}
