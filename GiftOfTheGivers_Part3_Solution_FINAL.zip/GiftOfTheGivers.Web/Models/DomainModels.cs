using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GiftOfTheGivers.Web.Models;

public class ReliefProject
{
    public int ProjectId { get; set; }

    [Required, StringLength(150)]
    public string ProjectName { get; set; } = string.Empty;

    [Required]
    public string Description { get; set; } = string.Empty;

    [StringLength(150)]
    public string Location { get; set; } = string.Empty;

    [StringLength(50)]
    public string Status { get; set; } = "Active";

    public DateTime StartDate { get; set; } = DateTime.UtcNow.Date;

    public string? PostedByUserId { get; set; }
}

public class Donation
{
    public int DonationId { get; set; }

    // Nullable so a guest ("anonymous donor") can donate without an account.
    public string? UserId { get; set; }

    [Required]
    public int ProjectId { get; set; }
    public ReliefProject? Project { get; set; }

    [Range(1, 1000000)]
    [Column(TypeName = "decimal(18,2)")]
    public decimal Amount { get; set; }

    [StringLength(3)]
    public string Currency { get; set; } = "ZAR";

    public bool IsRecurring { get; set; }

    public bool IsAnonymous { get; set; }

    [StringLength(150)]
    public string? DonorDisplayName { get; set; }

    public DateTime DonatedAt { get; set; } = DateTime.UtcNow;

    public TaxCertificate? Certificate { get; set; }
}

public class TaxCertificate
{
    public int CertificateId { get; set; }

    [Required]
    public int DonationId { get; set; }
    public Donation? Donation { get; set; }

    [Required, StringLength(30)]
    public string CertificateNumber { get; set; } = string.Empty;

    public DateTime IssuedAt { get; set; } = DateTime.UtcNow;
}

public class VolunteerSignup
{
    public int VolunteerId { get; set; }

    public string? UserId { get; set; }

    public int? ProjectId { get; set; }
    public ReliefProject? Project { get; set; }

    [Required, StringLength(150)]
    public string FullName { get; set; } = string.Empty;

    [Required, EmailAddress]
    public string Email { get; set; } = string.Empty;

    [Required, StringLength(500)]
    public string Skills { get; set; } = string.Empty;

    [Required, StringLength(200)]
    public string Availability { get; set; } = string.Empty;

    public DateTime RegisteredAt { get; set; } = DateTime.UtcNow;
}
