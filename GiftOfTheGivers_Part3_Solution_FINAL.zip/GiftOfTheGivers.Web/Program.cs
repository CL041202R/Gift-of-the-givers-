using GiftOfTheGivers.Web.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// --- Database ---------------------------------------------------------
// Default (local dev/tests): EF Core InMemory, so the app runs immediately with
// zero setup (per the brief: "data persistence can be minimal"). To point
// this at your real Azure SQL Database once it exists (Part 1 Section B),
// add a "DefaultConnection" string to appsettings.json and swap the two
// lines below.
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext<ApplicationDbContext>(options =>
{
    if (string.IsNullOrWhiteSpace(connectionString))
        options.UseInMemoryDatabase("GiftOfTheGiversDb");
    else
        options.UseSqlServer(connectionString);
});

// --- Identity -----------------------------------------------------------
builder.Services.AddIdentity<ApplicationUser, IdentityRole>(options =>
{
    options.Password.RequiredLength = 6;
    options.Password.RequireNonAlphanumeric = false;
    options.Password.RequireUppercase = false;
    options.SignIn.RequireConfirmedAccount = false;
})
    .AddEntityFrameworkStores<ApplicationDbContext>()
    .AddDefaultTokenProviders();

builder.Services.ConfigureApplicationCookie(options =>
{
    options.LoginPath = "/Account/Login";
    options.AccessDeniedPath = "/Account/AccessDenied";
});

builder.Services.AddControllersWithViews();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

using (var scope = app.Services.CreateScope())
{
    await DbInitializer.SeedAsync(scope.ServiceProvider);
}

app.Run();

// Part 3, Section A.2: top-level statements generate an internal `Program`
// class, which `WebApplicationFactory<Program>` (used by
// GiftOfTheGivers.Tests/DonationIntegrationTests.cs) cannot see across
// assemblies. This partial declaration only makes the class visible —
// it changes no runtime behaviour.
public partial class Program { }
