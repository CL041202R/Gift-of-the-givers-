using GiftOfTheGivers.Helpers;
using GiftOfTheGivers.Web.Data;
using GiftOfTheGivers.Web.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GiftOfTheGivers.Web.Controllers;

public class DonationController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly UserManager<ApplicationUser> _userManager;

    public DonationController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
    {
        _context = context;
        _userManager = userManager;
    }

    [HttpGet]
    public async Task<IActionResult> Index()
    {
        ViewBag.Projects = await _context.ReliefProjects.ToListAsync();
        return View(new Donation { Currency = "ZAR" });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Donation model, bool donateAsGuest, string? guestName)
    {
        if (!ModelState.IsValid)
        {
            ViewBag.Projects = await _context.ReliefProjects.ToListAsync();
            return View("Index", model);
        }

        var user = User.Identity?.IsAuthenticated == true ? await _userManager.GetUserAsync(User) : null;

        model.IsAnonymous = donateAsGuest || user is null;
        model.UserId = model.IsAnonymous ? null : user!.Id;
        model.DonorDisplayName = model.IsAnonymous ? (string.IsNullOrWhiteSpace(guestName) ? "Anonymous Donor" : guestName) : user!.FullName;
        model.DonatedAt = DateTime.UtcNow;

        _context.Donations.Add(model);
        await _context.SaveChangesAsync();

        // Part 2: certificate-number formatting now comes from the shared
        // GiftOfTheGivers.Helpers package (Section D) — the exact same
        // logic the GenerateTaxCertificate Azure Function (Section A) uses,
        // so a certificate looks identical whichever path generated it.
        var issuedAt = DateTime.UtcNow;
        var certificate = new TaxCertificate
        {
            DonationId = model.DonationId,
            CertificateNumber = DonationHelpers.FormatCertificateNumber(model.DonationId, issuedAt),
            IssuedAt = issuedAt,
        };
        _context.TaxCertificates.Add(certificate);
        await _context.SaveChangesAsync();

        return RedirectToAction(nameof(Certificate), new { id = model.DonationId });
    }

    [HttpGet]
    public async Task<IActionResult> Certificate(int id)
    {
        var donation = await _context.Donations
            .Include(d => d.Project)
            .Include(d => d.Certificate)
            .FirstOrDefaultAsync(d => d.DonationId == id);

        if (donation is null || donation.Certificate is null) return NotFound();

        return View(donation);
    }
}
