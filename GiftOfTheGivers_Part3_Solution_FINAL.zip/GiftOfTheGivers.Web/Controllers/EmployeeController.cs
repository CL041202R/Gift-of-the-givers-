using GiftOfTheGivers.Web.Data;
using GiftOfTheGivers.Web.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GiftOfTheGivers.Web.Controllers;

// Only Employee-role users may reach any action on this controller —
// this is the role-gating requirement from Section 3.2 of the brief.
[Authorize(Roles = "Employee")]
public class EmployeeController : Controller
{
    private readonly ApplicationDbContext _context;

    public EmployeeController(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<IActionResult> Dashboard()
    {
        ViewBag.Donations = await _context.Donations
            .Include(d => d.Project)
            .OrderByDescending(d => d.DonatedAt)
            .Take(20)
            .ToListAsync();

        ViewBag.Volunteers = await _context.VolunteerSignups
            .Include(v => v.Project)
            .OrderByDescending(v => v.RegisteredAt)
            .Take(20)
            .ToListAsync();

        return View(await _context.ReliefProjects.ToListAsync());
    }

    [HttpGet]
    public IActionResult PostUpdate() => View(new ReliefProject { Status = "Active" });

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> PostUpdate(ReliefProject model)
    {
        if (!ModelState.IsValid) return View(model);

        model.PostedByUserId = User.Identity?.Name;
        _context.ReliefProjects.Add(model);
        await _context.SaveChangesAsync();

        return RedirectToAction(nameof(Dashboard));
    }
}
