using GiftOfTheGivers.Web.Data;
using Microsoft.AspNetCore.Mvc;

namespace GiftOfTheGivers.Web.Controllers;

public class HomeController : Controller
{
    private readonly ApplicationDbContext _context;

    public HomeController(ApplicationDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        var projects = _context.ReliefProjects.OrderByDescending(p => p.StartDate).ToList();
        return View(projects);
    }

    public IActionResult About() => View();

    public IActionResult Contact() => View();
}
