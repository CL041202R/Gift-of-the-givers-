using GiftOfTheGivers.Web.Data;
using GiftOfTheGivers.Web.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GiftOfTheGivers.Web.Controllers;

public class VolunteerController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly UserManager<ApplicationUser> _userManager;

    public VolunteerController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
    {
        _context = context;
        _userManager = userManager;
    }

    [HttpGet]
    public async Task<IActionResult> Index()
    {
        ViewBag.Projects = await _context.ReliefProjects.ToListAsync();
        return View(new VolunteerSignup());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(VolunteerSignup model)
    {
        if (!ModelState.IsValid)
        {
            ViewBag.Projects = await _context.ReliefProjects.ToListAsync();
            return View("Index", model);
        }

        if (User.Identity?.IsAuthenticated == true)
        {
            var user = await _userManager.GetUserAsync(User);
            model.UserId = user?.Id;
        }

        model.RegisteredAt = DateTime.UtcNow;
        _context.VolunteerSignups.Add(model);
        await _context.SaveChangesAsync();

        return RedirectToAction(nameof(ThankYou));
    }

    [HttpGet]
    public IActionResult ThankYou() => View();
}
