const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, BorderStyle, ShadingType,
} = require("docx");
const fs = require("fs");

const BRAND_RED = "C1272D";
const GREY = "6B6B6B";
const HEADER_FILL = "C1272D";

const CELL_BORDERS = {
  top: { style: BorderStyle.SINGLE, size: 4, color: "BFBFBF" },
  bottom: { style: BorderStyle.SINGLE, size: 4, color: "BFBFBF" },
  left: { style: BorderStyle.SINGLE, size: 4, color: "BFBFBF" },
  right: { style: BorderStyle.SINGLE, size: 4, color: "BFBFBF" },
};

function headerCell(text, widthPct) {
  return new TableCell({
    width: { size: widthPct, type: WidthType.PERCENTAGE },
    shading: { type: ShadingType.CLEAR, fill: HEADER_FILL },
    borders: CELL_BORDERS,
    margins: { top: 100, bottom: 100, left: 120, right: 120 },
    children: [new Paragraph({ children: [new TextRun({ text, bold: true, color: "FFFFFF" })] })],
  });
}

function bodyCell(text, widthPct, opts = {}) {
  return new TableCell({
    width: { size: widthPct, type: WidthType.PERCENTAGE },
    borders: CELL_BORDERS,
    margins: { top: 100, bottom: 100, left: 120, right: 120 },
    children: [new Paragraph({ children: [new TextRun({ text, ...opts })] })],
  });
}

function h1(text) {
  return new Paragraph({ text, heading: HeadingLevel.HEADING_1, spacing: { before: 320, after: 140 } });
}

function body(text, opts = {}) {
  return new Paragraph({ spacing: { after: 160 }, children: [new TextRun({ text, ...opts })] });
}

function spacer(h = 120) {
  return new Paragraph({ text: "", spacing: { after: h } });
}

const columnWidths = [22, 16, 42, 20]; // must sum to 100

const rows = [
  ["[Team member name]", "Project Lead", "Overall planning and coordination; Part 1 Azure Boards setup; final handover package compilation.", "[Evidence, e.g. commit links]"],
  ["[Team member name]", "Database Designer", "Designed the Azure SQL schema and ERD (Part 1, Section B); wrote and applied the Azure SQL schema scripts (Part 3, C.3).", "[Evidence]"],
  ["[Team member name]", "Developer", "Built the ASP.NET Core prototype (Part 1), Azure Functions and Helpers library (Part 2), unit/integration tests (Part 3, Section A).", "[Evidence]"],
  ["[Team member name]", "Developer", "Implemented donation and volunteer flows; branching/merging in Azure Repos (Part 2, Section B).", "[Evidence]"],
  ["[Team member name]", "Quality Reviewer / Deployment Lead", "Wrote Selenium UI tests and the load test (Part 3, Section A); configured the CI/CD pipeline and Azure deployments (Part 3, Sections B & C).", "[Evidence]"],
];

const table = new Table({
  width: { size: 100, type: WidthType.PERCENTAGE },
  rows: [
    new TableRow({
      tableHeader: true,
      children: [
        headerCell("Team member", columnWidths[0]),
        headerCell("Role", columnWidths[1]),
        headerCell("Responsibilities / contribution", columnWidths[2]),
        headerCell("Evidence", columnWidths[3]),
      ],
    }),
    ...rows.map(([name, role, contrib, evidence]) => new TableRow({
      children: [
        bodyCell(name, columnWidths[0], { italics: true, color: GREY }),
        bodyCell(role, columnWidths[1]),
        bodyCell(contrib, columnWidths[2]),
        bodyCell(evidence, columnWidths[3], { italics: true, color: GREY }),
      ],
    })),
  ],
});

const doc = new Document({
  styles: {
    default: { document: { run: { font: "Calibri", size: 22 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", run: { size: 32, bold: true, color: BRAND_RED } },
    ],
  },
  sections: [
    {
      properties: { page: { size: { width: 12240, height: 15840 } } }, // US Letter
      children: [
        new Paragraph({
          children: [new TextRun({ text: "Gift of the Givers Foundation — Web Application", bold: true, size: 32, color: BRAND_RED })],
          spacing: { after: 80 },
        }),
        new Paragraph({
          children: [new TextRun({ text: "Team Contribution Report", size: 26, color: "2B2B2B" })],
          spacing: { after: 40 },
        }),
        new Paragraph({
          children: [new TextRun({ text: "Part 3, Section D — Project Handover", italics: true, color: GREY })],
          spacing: { after: 40 },
        }),
        new Paragraph({
          children: [new TextRun({ text: "Group name: [insert group / class code]     Date: [insert date]", color: GREY })],
          spacing: { after: 260 },
        }),

        body(
          "This report records which member of the group was responsible for which part of the Gift of the " +
          "Givers Foundation web application project, across all three parts of the Portfolio of Evidence " +
          "(Part 1: planning & prototype, Part 2: Functions/Repos/Pipelines/Artifacts, Part 3: testing, " +
          "deployment & handover). Replace the placeholder names, roles and evidence links below with your " +
          "group's actual details before submitting."
        ),

        table,
        spacer(200),

        h1("Notes"),
        body("• A member may hold more than one role, or roles may be shared — adjust the table above to match how your group actually worked."),
        body("• \u201cEvidence\u201d should point to something checkable: an Azure Repos commit author/link, a Boards work item assigned to that person, or a pipeline run they triggered."),
        body("• If your group used a different role split than the four suggested in the brief (Project Lead, Database Designer, Developer, Quality Reviewer), list your own — the goal is a clear, honest record of who did what."),
      ],
    },
  ],
});

Packer.toBuffer(doc).then((buffer) => {
  fs.writeFileSync("TeamContributionReport.docx", buffer);
  console.log("TeamContributionReport.docx written");
});
