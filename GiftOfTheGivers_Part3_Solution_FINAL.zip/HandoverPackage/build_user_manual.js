const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, BorderStyle, ShadingType,
  Numbering, LevelFormat, PageBreak,
} = require("docx");
const fs = require("fs");

const BRAND_RED = "C1272D";
const GREY = "6B6B6B";
const LIGHT_GREY_FILL = "F2F2F2";

function h1(text) {
  return new Paragraph({
    text,
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 160 },
  });
}

function h2(text) {
  return new Paragraph({
    text,
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 280, after: 120 },
  });
}

function body(text, opts = {}) {
  return new Paragraph({
    spacing: { after: 160 },
    children: [new TextRun({ text, ...opts })],
  });
}

function bullet(text) {
  return new Paragraph({
    text,
    numbering: { reference: "bullet-list", level: 0 },
    spacing: { after: 80 },
  });
}

function numbered(text, listRef = "numbered-list-1") {
  return new Paragraph({
    text,
    numbering: { reference: listRef, level: 0 },
    spacing: { after: 80 },
  });
}

// A bordered, shaded placeholder box standing in for a real screenshot —
// the brief requires "screenshots of the application with simple
// explanations"; your group should replace each of these with an actual
// screenshot once the app is running/deployed.
function screenshotPlaceholder(caption) {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: [
      new TableRow({
        children: [
          new TableCell({
            width: { size: 100, type: WidthType.PERCENTAGE },
            shading: { type: ShadingType.CLEAR, fill: LIGHT_GREY_FILL },
            borders: {
              top: { style: BorderStyle.SINGLE, size: 6, color: "BFBFBF" },
              bottom: { style: BorderStyle.SINGLE, size: 6, color: "BFBFBF" },
              left: { style: BorderStyle.SINGLE, size: 6, color: "BFBFBF" },
              right: { style: BorderStyle.SINGLE, size: 6, color: "BFBFBF" },
            },
            margins: { top: 200, bottom: 200, left: 200, right: 200 },
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({
                    text: `[Insert screenshot: ${caption}]`,
                    italics: true,
                    color: GREY,
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });
}

function spacer() {
  return new Paragraph({ text: "", spacing: { after: 120 } });
}

const doc = new Document({
  numbering: {
    config: [
      {
        reference: "bullet-list",
        levels: [
          { level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 480, hanging: 240 } } } },
        ],
      },
      ...["numbered-list-1", "numbered-list-2", "numbered-list-3", "numbered-list-4", "numbered-list-5"].map((reference) => ({
        reference,
        levels: [
          { level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 480, hanging: 240 } } } },
        ],
      })),
    ],
  },
  styles: {
    default: {
      document: { run: { font: "Calibri", size: 22 } }, // 11pt
    },
    paragraphStyles: [
      {
        id: "Heading1",
        name: "Heading 1",
        basedOn: "Normal",
        next: "Normal",
        run: { size: 32, bold: true, color: BRAND_RED },
      },
      {
        id: "Heading2",
        name: "Heading 2",
        basedOn: "Normal",
        next: "Normal",
        run: { size: 26, bold: true, color: "2B2B2B" },
      },
    ],
  },
  sections: [
    {
      properties: {
        page: { size: { width: 12240, height: 15840 } }, // US Letter
      },
      children: [
        // --- Title page -----------------------------------------------
        new Paragraph({ text: "", spacing: { after: 1600 } }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: "Gift of the Givers Foundation", bold: true, size: 48, color: BRAND_RED })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 200, after: 100 },
          children: [new TextRun({ text: "Web Application — User Manual", size: 32, color: "2B2B2B" })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 400 },
          children: [new TextRun({ text: "Prepared for Foundation staff (non-technical)", italics: true, color: GREY })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 100 },
          children: [new TextRun({ text: "Part 3, Section D — Project Handover Package", color: GREY })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 100 },
          children: [new TextRun({ text: "Version 1.0 — [insert date]", color: GREY })],
        }),
        new Paragraph({ children: [new PageBreak()] }),

        // --- 1. Introduction --------------------------------------------
        h1("1. Introduction"),
        body(
          "This manual explains how to use the Gift of the Givers Foundation web application. " +
          "It is written for Foundation staff and does not assume any technical background. " +
          "The application lets the public donate to relief projects, sign up to volunteer, and lets " +
          "Foundation employees post updates about ongoing relief work."
        ),
        body("The application has three kinds of user:"),
        bullet("Anonymous visitor — can browse projects, donate as a guest, and sign up to volunteer without an account."),
        bullet("Donor — a registered account that can donate and keep a record of past donations."),
        bullet("Employee — a Foundation staff account that can post relief-project updates and view a dashboard of recent donations and volunteer sign-ups."),
        spacer(),

        // --- 2. Login instructions --------------------------------------
        h1("2. Logging In"),
        h2("2.1 Employees"),
        body("If you're a Foundation employee, you'll be given a login (email address) and password by your administrator."),
        numbered("Click Log in in the top-right of any page.", "numbered-list-1"),
        numbered("Enter your email address and password.", "numbered-list-1"),
        numbered("Click Log in. You'll see a Dashboard link appear in the top menu — this only appears for Employee accounts.", "numbered-list-1"),
        screenshotPlaceholder("The Log in page"),
        spacer(),
        h2("2.2 Donors"),
        body("If you'd like an account to keep track of your donations:"),
        numbered("Click Register in the top-right of any page.", "numbered-list-2"),
        numbered("Fill in your name, email address, and choose a password.", "numbered-list-2"),
        numbered("Click Register — you'll be logged in automatically.", "numbered-list-2"),
        body("You do not need an account to donate — see section 3 below."),
        spacer(),
        h2("2.3 Anonymous visitors"),
        body(
          "You don't need to log in or register to donate or to sign up as a volunteer. Just fill in the " +
          "relevant form and, where a donation is concerned, tick or leave ticked the guest option so your " +
          "donation is recorded as anonymous."
        ),
        spacer(),

        // --- 3. Making a donation -----------------------------------------
        h1("3. Making a Donation"),
        numbered("Click Donate in the top menu.", "numbered-list-3"),
        numbered("Choose which relief project you'd like to support from the drop-down list.", "numbered-list-3"),
        numbered("Enter the amount you'd like to donate.", "numbered-list-3"),
        numbered("Choose the currency — ZAR, USD, or EUR.", "numbered-list-3"),
        numbered("Tick \u201cMake this a recurring monthly donation\u201d if you'd like the donation to repeat every month; leave it unticked for a once-off donation.", "numbered-list-3"),
        numbered("If you're not logged in, you'll see a guest box — you can optionally type a name to appear on your certificate, or leave it blank to donate as \u201cAnonymous Donor.\u201d", "numbered-list-3"),
        numbered("Click Donate.", "numbered-list-3"),
        screenshotPlaceholder("The Donate page, filled in"),
        body(
          "Note: this prototype records donations for demonstration purposes only — no real payment is " +
          "processed and no money changes hands."
        ),
        spacer(),

        // --- 4. Tax certificate -----------------------------------------
        h1("4. Getting Your Tax Certificate"),
        body(
          "As soon as a donation is submitted, the system automatically generates a certificate and takes " +
          "you straight to it — there's nothing extra to click."
        ),
        bullet("The certificate shows a unique certificate number (for example GOTG-2026-000123), the donor name, project, amount, and date."),
        bullet("Click Print / Save as PDF on that page to print it or save it as a PDF file for your records."),
        screenshotPlaceholder("A generated tax certificate"),
        body(
          "Note: at this stage certificates are placeholders for demonstration purposes and have no legal tax validity."
        ),
        spacer(),

        // --- 5. Volunteering -----------------------------------------
        h1("5. Registering as a Volunteer"),
        numbered("Click Volunteer in the top menu.", "numbered-list-4"),
        numbered("Fill in your full name, email address, the skills you can offer, and when you're available.", "numbered-list-4"),
        numbered("Optionally choose a specific relief project you'd like to help with.", "numbered-list-4"),
        numbered("Click Submit — you'll see a thank-you confirmation page.", "numbered-list-4"),
        screenshotPlaceholder("The Volunteer sign-up page"),
        body("A Foundation employee will see your sign-up on their dashboard (see section 6) and can follow up with you directly."),
        spacer(),

        // --- 6. Employee dashboard / posting updates -----------------------------------------
        h1("6. Posting a Project Update (Employees only)"),
        body("Once logged in as an Employee:"),
        numbered("Click Dashboard in the top menu.", "numbered-list-5"),
        numbered("Here you can see the most recent donations, volunteer sign-ups, and all relief projects at a glance.", "numbered-list-5"),
        numbered("Click Post project update.", "numbered-list-5"),
        numbered("Fill in the project name, description, location, and status (e.g. Active, Completed).", "numbered-list-5"),
        numbered("Click Save — the new update appears immediately on the dashboard and becomes available for donors and volunteers to choose from.", "numbered-list-5"),
        screenshotPlaceholder("The Employee dashboard"),
        screenshotPlaceholder("The Post project update form"),
        spacer(),

        // --- 7. Troubleshooting -----------------------------------------
        h1("7. Frequently Asked Questions"),
        h2("I forgot my password. What do I do?"),
        body("Contact your system administrator — password reset via email is planned for a future release of this application."),
        h2("Can I edit or cancel a donation after submitting it?"),
        body("Not in this version. Please contact a Foundation employee directly if a correction is needed."),
        h2("Why can't I see the Dashboard link?"),
        body("The Dashboard is only visible to Employee accounts. If you believe you should have employee access, contact your administrator."),
        spacer(),

        // --- 8. Support -----------------------------------------
        h1("8. Getting Help"),
        body("For any issue not covered in this manual, please contact your project's Quality Reviewer / IT support contact — see the accompanying Team Contribution Report for names and roles."),
      ],
    },
  ],
});

Packer.toBuffer(doc).then((buffer) => {
  fs.writeFileSync("UserManual.docx", buffer);
  console.log("UserManual.docx written");
});
